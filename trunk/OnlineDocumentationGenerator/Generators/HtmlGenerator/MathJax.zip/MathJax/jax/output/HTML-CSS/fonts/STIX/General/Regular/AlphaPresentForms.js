/*
 *  /MathJax/jax/output/HTML-CSS/fonts/STIX/General/Regular/AlphaPresentForms.js
 *  
 *  Copyright (c) 2012 Design Science, Inc.
 *
 *  Part of the MathJax library.
 *  See http://www.mathjax.org for details.
 * 
 *  Licensed under the Apache License, Version 2.0;
 *  you may not use this file except in compliance with the License.
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 */

MathJax.Hub.Insert(MathJax.OutputJax["HTML-CSS"].FONTDATA.FONTS.STIXGeneral,{64256:[683,0,605,20,655],64257:[683,0,558,32,523],64258:[683,0,556,31,522],64259:[683,0,832,20,797],64260:[683,0,830,20,796]});MathJax.Ajax.loadComplete(MathJax.OutputJax["HTML-CSS"].fontDir+"/General/Regular/AlphaPresentForms.js");

